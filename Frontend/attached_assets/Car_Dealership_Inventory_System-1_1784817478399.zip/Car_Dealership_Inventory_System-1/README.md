# Car Dealership Inventory System

A Spring Boot REST API for managing a car dealership's vehicle inventory, purchases, customers, employees, test drives, and payments — with JWT-based authentication and role-based access control.

> **Note on this document:** This README was compiled from a static review of the source tree. Maven was not available in the environment used to prepare this package, so **no build or test run has been performed against this exact copy** — see "Testing Instructions" below for what to run yourself before treating it as verified.

---

## 1. Project Overview

The Car Dealership Inventory System is a backend application that digitizes the day-to-day operations of a car dealership: tracking vehicle stock, recording purchases and purchase history, managing employees and customers, booking test drives, and processing payments — all behind a secured, documented REST API.

## 2. Project Features

- Full CRUD vehicle inventory management with search/filter support
- Purchase recording and purchase history tracking
- Employee and customer management
- Test drive booking workflow
- Payment recording and history
- JWT-based authentication with role-based authorization
- Centralized exception handling and request validation
- Interactive API documentation via Swagger / OpenAPI
- Unit, controller, security, and integration test coverage

## 3. Application Architecture

The project follows a standard layered Spring Boot architecture:

```
Controller  →  Service (interface)  →  Service Impl  →  Repository  →  Database
                       ↑
                  DTO (Request/Response) + Mapper
```

- **Controller layer** — exposes REST endpoints, delegates to services
- **Service layer** — interfaces defining business operations, implemented in `service.impl`
- **Repository layer** — Spring Data JPA repositories for persistence
- **Entity layer** — JPA entities mapped to PostgreSQL tables
- **DTO layer** — request/response objects, decoupled from entities via mappers
- **Security layer** — JWT filter chain, user details service, access-denied/entry-point handlers
- **Exception layer** — centralized `@ControllerAdvice`-based error handling

## 4. Technology Stack

| Layer | Technology |
|---|---|
| Language | Java 21 |
| Framework | Spring Boot 3.5.16 |
| Web | Spring Web (MVC) |
| Persistence | Spring Data JPA / Hibernate |
| Database | PostgreSQL |
| Security | Spring Security + JWT (jjwt 0.12.6) |
| Validation | Spring Boot Starter Validation |
| API Docs | springdoc-openapi (Swagger UI) |
| Testing | JUnit 5, Spring Boot Test, Spring Security Test, Testcontainers (PostgreSQL) |
| Build Tool | Maven |
| Boilerplate reduction | Lombok |

## 5. Module Details

| Module | Responsibility |
|---|---|
| **Vehicle Management** | Add, update, delete, search, and list vehicles in inventory |
| **Purchase Management** | Record vehicle purchases against customers/employees |
| **Purchase History** | Query historical purchase records |
| **Employee Management** | CRUD operations for dealership staff |
| **Customer Management** | CRUD operations for customer records |
| **Test Drive Booking** | Schedule and manage test drive appointments |
| **Payment Management** | Record and retrieve payment transactions |
| **Inventory Management** | Advanced stock-level operations and inventory logs |

Controllers implementing these modules: `VehicleController`, `PurchaseController`, `CustomerController`, `EmployeeController`, `TestDriveController`, `PaymentController`, `InventoryController`, `AuthController`.

## 6. Database Configuration

The application connects to PostgreSQL via `src/main/resources/application.properties`:

```properties
spring.datasource.url=jdbc:postgresql://localhost:5432/car_dealership_db
spring.datasource.username=postgres
spring.datasource.password=<your-password>
spring.jpa.hibernate.ddl-auto=update
```

**Before running:** create a local database named `car_dealership_db`, and update the username/password to match your PostgreSQL instance.

> ⚠️ **Security note:** the checked-in `application.properties` currently has a real-looking datasource password and JWT secret committed in plaintext. Before treating this as production-ready, move both `spring.datasource.password` and `jwt.secret` out to environment variables or a secrets manager, and rotate the JWT secret.

## 7. Security Implementation

- Stateless session management via Spring Security
- Custom `JwtAuthenticationFilter` intercepts requests and validates bearer tokens
- `CustomUserDetailsService` loads user details from the database
- `CustomAccessDeniedHandler` and `JwtAuthenticationEntryPoint` provide consistent 401/403 responses
- Role-based method/endpoint authorization

> **Cleanup note:** the security package contains both `JwtUtil` (used throughout controllers, filters, and most tests) and a thinner `JwtService`/`JwtServiceImpl` pair that only wraps `JwtUtil.generateToken(...)` and is referenced by a single test. This looks like a leftover/duplicate token-generation path from an earlier phase — worth removing or consolidating into `JwtUtil` once you've confirmed nothing else depends on it.

## 8. JWT Authentication

1. User logs in via `AuthController` with credentials
2. On success, a signed JWT is issued (expiry configurable via `jwt.expiration`, currently 24h)
3. Subsequent requests must include `Authorization: Bearer <token>`
4. `JwtAuthenticationFilter` validates the token on every request and populates the security context

## 9. API Documentation

API documentation is auto-generated via springdoc-openapi and available once the app is running:

- OpenAPI JSON: `http://localhost:8087/v3/api-docs`

## 10. Swagger Usage

Swagger UI is available at:

```
http://localhost:8087/swagger-ui/index.html
```

Use it to explore and test all endpoints interactively. Endpoints requiring authentication need a valid JWT supplied via the "Authorize" button.

## 11. Running Instructions

**Prerequisites:** Java 21, Maven, PostgreSQL running locally.

```bash
# 1. Create the database
createdb car_dealership_db

# 2. Update credentials in src/main/resources/application.properties

# 3. Build
mvn clean package

# 4. Run
mvn spring-boot:run
# or
java -jar target/car-dealership-0.0.1-SNAPSHOT.jar
```

The app starts on port `8087` by default (`server.port` in `application.properties`).

## 12. Testing Instructions

This package has **not** been compiled or test-verified in the environment it was assembled in (no Maven/network access available there). Before relying on it, run the full suite yourself:

```bash
# Run all tests (unit, controller, security, integration)
mvn clean test

# Full build including packaging
mvn clean package
```

Test coverage includes entity, DTO, repository, service, controller, security, and integration tests (the integration tests use Testcontainers, so Docker must be running locally).

If any test fails, address it before treating this as a final, submission-ready build.
