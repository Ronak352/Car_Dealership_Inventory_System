import React from 'react'
import { useAuth } from '../../hooks/useAuth'
import { Car, Users, Briefcase, Warehouse, ShoppingCart, CreditCard, CalendarCheck } from 'lucide-react'

// Role-specific dashboards (Admin / Inventory Manager / Sales Executive /
// Accountant) with real KPI data land in Phase 4 once the list endpoints
// they aggregate (vehicles, purchases, payments, etc.) are wired up in
// Phase 2 & 3. This phase-1 placeholder confirms auth + layout work end to end.
const roleCopy = {
  ADMIN: { title: 'Admin overview', desc: 'Full access to vehicles, customers, employees, inventory, purchases, payments and test drives.' },
  MANAGER: { title: 'Manager overview', desc: 'Manage inventory, vehicles, employees and oversee purchases and test drives.' },
  SALESPERSON: { title: 'Sales overview', desc: 'Track your customers, test drives and purchases.' },
  CUSTOMER: { title: 'My dashboard', desc: 'Browse vehicles, book test drives and track your purchases.' },
}

const modules = [
  { icon: Car, label: 'Vehicles', note: 'Phase 2' },
  { icon: Users, label: 'Customers', note: 'Phase 2' },
  { icon: Briefcase, label: 'Employees', note: 'Phase 2' },
  { icon: Warehouse, label: 'Inventory', note: 'Phase 3' },
  { icon: ShoppingCart, label: 'Purchases', note: 'Phase 3' },
  { icon: CreditCard, label: 'Payments', note: 'Phase 3' },
  { icon: CalendarCheck, label: 'Test Drives', note: 'Phase 3' },
]

export default function Dashboard() {
  const { user } = useAuth()
  const copy = roleCopy[user?.role] || roleCopy.CUSTOMER

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">{copy.title}</h1>
        <p className="text-gray-500 mt-1">{copy.desc}</p>
      </div>

      <div className="card p-4 flex items-center gap-3">
        <span className="flex h-10 w-10 items-center justify-center rounded-full bg-primary-100 text-primary-700 dark:bg-primary-900/40 dark:text-primary-300 font-semibold">
          {user?.email?.[0]?.toUpperCase()}
        </span>
        <div>
          <p className="font-medium">{user?.email}</p>
          <p className="text-sm text-gray-500">Signed in as {user?.role}</p>
        </div>
      </div>

      <div>
        <h2 className="text-lg font-semibold mb-3">Coming up next</h2>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {modules.map(({ icon: Icon, label, note }) => (
            <div key={label} className="card p-4 flex items-center justify-between opacity-70">
              <div className="flex items-center gap-3">
                <Icon className="h-6 w-6 text-primary-600" />
                <span className="font-medium">{label}</span>
              </div>
              <span className="text-xs text-gray-400">{note}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
