import axiosClient from './axiosClient'

// Partial wrapper around com.dealership.controller.PurchaseController.
// Only the one endpoint needed for CustomerPurchaseHistory in Phase 2B is
// exposed here -- create/get-by-id/by-vehicle/by-salesperson land in
// Phase 5's purchase module. This file is extended then, not replaced.

// GET /api/purchases/customer/{customerId} -- ADMIN, MANAGER, SALESPERSON,
// CUSTOMER.
//
// Known backend limitation: the endpoint only checks role, not ownership --
// a CUSTOMER-role caller can pass any customerId and get that customer's
// purchase history back, not just their own. That's enforced (or not)
// server-side and can't be fixed from here per the backend-protection rule.
// The frontend only ever calls this with the id of the customer profile
// currently being viewed (the signed-in customer's own profile, or one an
// admin/manager/salesperson opened from the customer list/details page).
export function getPurchasesByCustomer(customerId) {
  return axiosClient.get(`/purchases/customer/${customerId}`).then((res) => res.data)
}
