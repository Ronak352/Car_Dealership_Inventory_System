# DriveHub — Vehicle Dealership Frontend

React + Vite + Tailwind frontend for the Spring Boot **Car Dealership Inventory System** backend.

## Phase 1 — Project Foundation + Authentication

This ZIP contains **Phase 1 only**. Later phases (2–5) will be delivered as
additional ZIPs, each containing all previous work plus new modules, per the
project brief.

### What's included

- Vite + React 18 + Tailwind CSS project scaffold
- Axios client (`src/api/axiosClient.js`) with a JWT request interceptor and
  a response interceptor that normalizes backend error payloads and forces
  re-login on `401`
- `AuthContext` + `useAuth()` hook: login, register, logout, session
  persistence in `localStorage`, JWT expiry check on load
- Protected routes (`ProtectedRoute`) and a role-gating route
  (`RoleRoute`, ready for use once role-restricted pages exist in Phase 2+)
- Pages: Landing, Login, Register, Forgot Password, Reset Password
- Dashboard layout: Navbar, Sidebar (role-aware nav list), Footer, dark mode
- Reusable components: Button, Input, Select, Modal, Table, Loader, Badge,
  ErrorMessage, Toast notifications
- System pages: 404 (Not Found), 403 (Forbidden) — full polish continues in Phase 5

### Backend contract this phase relies on

From `AuthController` (`/api/auth`, public, no bearer token required):

| Method | Path | Request | Response |
|---|---|---|---|
| POST | `/api/auth/register` | `RegisterRequest{firstName,lastName,email,phone,password,role}` | `AuthResponse{userId,email,role,token}` (201) |
| POST | `/api/auth/login` | `LoginRequest{email,password}` | `AuthResponse{userId,email,role,token}` (200) |

**Design decisions made from the actual backend code (not guessed):**

- Roles are exactly `ADMIN`, `MANAGER`, `SALESPERSON`, `CUSTOMER`
  (`com.dealership.enums.Role`). The public **Register** form always sends
  `role: "CUSTOMER"` — `RegisterRequest.role` is `@NotNull`, but there is no
  public/self-service path in the backend to create ADMIN/MANAGER/SALESPERSON
  accounts; those are provisioned by an ADMIN via `EmployeeController`
  (`POST /api/employees`), which Phase 2 will wire up.
- **There is no password-reset endpoint in the backend** (only
  `/register` and `/login` exist on `AuthController`). The Forgot/Reset
  Password pages are real, styled screens, but they clearly disclose this
  limitation instead of calling a fake endpoint, per the "no fake APIs" rule.
  Wire them to real endpoints as soon as the backend adds
  `forgot-password` / `reset-password`.
- Errors are parsed from the backend's actual `ErrorResponse` shape
  (`{timestamp,status,error,message,path}`) thrown by `GlobalExceptionHandler`.
- `server.port=8087` and the backend has no context path beyond `/api`, so
  `VITE_API_BASE_URL=http://localhost:8087/api` (see `.env`).

### Running it

```bash
npm install
npm run dev
```

Make sure the backend is running on `localhost:8087` (or update
`VITE_API_BASE_URL` in `.env`), and that CORS is enabled for
`http://localhost:5173` on the backend (not modified per the brief — configure
this on the backend side, e.g. a `WebMvcConfigurer` CORS mapping, if you hit
CORS errors).

### Coming in later phases

- **Phase 2**: Vehicle, Customer, Employee CRUD pages (list/add/edit/details/search/filter)
- **Phase 3**: Inventory, Purchase, Payment, Test Drive modules
- **Phase 4**: Role-based dashboards with real KPIs/charts, Reports
- **Phase 5**: Profile/Settings, final polish, Docker + production build
